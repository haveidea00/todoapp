package com.example.todoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

data class Task(
    val title: String = "",
    val detail: String = "",
    val completed: Boolean = false,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val color: String = "Gray",
    val subtasks: List<String> = emptyList(),
    val subtaskColors: List<String> = emptyList(),
    val backgroundColor: String = "White"
)

class MainActivity : ComponentActivity() {
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)
        database = FirebaseDatabase
            .getInstance("https://todoapp-fd4d6-default-rtdb.asia-southeast1.firebasedatabase.app/")
            .getReference("tasks")

        setContent {
            var backgroundColor by remember { mutableStateOf(Color(0xFFFAF3E0)) }

            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = backgroundColor
                ) {
                    TodoApp(database, onBackgroundChange = { backgroundColor = it })
                }
            }
        }
    }
}

@Composable
fun TodoApp(database: DatabaseReference, onBackgroundChange: (Color) -> Unit) {
    var taskTitle by remember { mutableStateOf("") }
    var taskDetail by remember { mutableStateOf("") }
    var subtaskText by remember { mutableStateOf("") }
    var subtasks by remember { mutableStateOf(mutableListOf<String>()) }
    var subtaskColors by remember { mutableStateOf(mutableListOf<String>()) }
    var tasks by remember { mutableStateOf(listOf<Pair<String, Task>>()) }
    var bold by remember { mutableStateOf(false) }
    var italic by remember { mutableStateOf(false) }
    var color by remember { mutableStateOf("Gray") }
    var subtaskColor by remember { mutableStateOf("Gray") }
    var showAddTaskFields by remember { mutableStateOf(false) }
    var editingKey by remember { mutableStateOf<String?>(null) }
    var taskBackground by remember { mutableStateOf("White") }

    val backgroundOptions = listOf(
        "White" to Color.White,
        "Peach" to Color(0xFFFFE5B4),
        "Blue" to Color(0xFFD0E8F2),
        "Pink" to Color(0xFFFFC0CB)
    )

    val fontColorOptions = mapOf(
        "Red" to Color.Red,
        "Blue" to Color.Blue,
        "Green" to Color.Green,
        "Yellow" to Color.Yellow,
        "White" to Color.White,
        "Gray" to Color.Gray,
        "Pink" to Color(0xFFFFC0CB)
    )

    LaunchedEffect(Unit) {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val newTasks = mutableListOf<Pair<String, Task>>()
                for (task in snapshot.children) {
                    val taskData = task.getValue(Task::class.java)
                    val key = task.key
                    if (taskData != null && key != null) {
                        newTasks.add(key to taskData)
                    }
                }
                tasks = newTasks
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text("To Do List", fontSize = 32.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, color = Color(0xFF1E3A8A), textAlign = TextAlign.Center)
            Text("Jan Ryan Erana", color = Color.Gray, textAlign = TextAlign.Center)
            Text("Reynan Zapanta", color = Color.Gray, textAlign = TextAlign.Center)
            Text("Cenon Paul Seron", color = Color.Gray, textAlign = TextAlign.Center)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
            backgroundOptions.forEach { (name, colorValue) ->
                Button(onClick = { onBackgroundChange(colorValue) }) {
                    Text(name)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (!showAddTaskFields) {
            Button(onClick = {
                showAddTaskFields = true
                editingKey = null
                taskTitle = ""
                taskDetail = ""
                subtasks.clear()
                subtaskColors.clear()
                bold = false
                italic = false
                color = "Gray"
                subtaskColor = "Gray"
                taskBackground = "White"
            }) {
                Text("Add Task")
            }
        }

        if (showAddTaskFields) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(value = taskTitle, onValueChange = { taskTitle = it }, label = { Text("Task Title") })
                OutlinedTextField(value = taskDetail, onValueChange = { taskDetail = it }, label = { Text("Task Detail") })

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = bold, onCheckedChange = { bold = it })
                    Text("Bold")
                    Checkbox(checked = italic, onCheckedChange = { italic = it })
                    Text("Italic")
                }

                Text("Font Color:")
                DropdownMenuBox(fontColorOptions.keys.toList(), color) { selected -> color = selected }

                Text("Task Background Color:")
                Row {
                    backgroundOptions.forEach { (name, _) ->
                        Button(onClick = { taskBackground = name }) {
                            Text(name)
                        }
                    }
                }

                OutlinedTextField(value = subtaskText, onValueChange = { subtaskText = it }, label = { Text("Subtask") })

                Text("Subtask Font Color:")
                DropdownMenuBox(fontColorOptions.keys.toList(), subtaskColor) { selected -> subtaskColor = selected }

                Button(onClick = {
                    if (subtaskText.isNotBlank()) {
                        subtasks.add(subtaskText)
                        subtaskColors.add(subtaskColor)
                        subtaskText = ""
                    }
                }) {
                    Text("Add Subtask")
                }

                if (subtasks.isNotEmpty()) {
                    Text("Preview Subtasks:")
                    subtasks.forEachIndexed { index, subtask ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val subColor = fontColorOptions[subtaskColors[index]] ?: Color.Gray
                            var editingSubtask by remember { mutableStateOf(false) }
                            var editedText by remember { mutableStateOf(subtask) }

                            if (editingSubtask) {
                                OutlinedTextField(
                                    value = editedText,
                                    onValueChange = { editedText = it },
                                    modifier = Modifier.weight(1f)
                                )
                                Button(onClick = {
                                    subtasks[index] = editedText
                                    editingSubtask = false
                                }) {
                                    Text("Save")
                                }
                            } else {
                                Text(text = "- $subtask", color = subColor, modifier = Modifier.weight(1f))
                                Button(onClick = {
                                    editingSubtask = true
                                    editedText = subtask
                                }) {
                                    Text("Edit")
                                }
                            }
                        }
                    }
                }

                Button(onClick = {
                    val task = Task(taskTitle, taskDetail, false, bold, italic, color, subtasks, subtaskColors, taskBackground)
                    if (editingKey != null) {
                        database.child(editingKey!!).setValue(task)
                    } else {
                        database.push().setValue(task)
                    }
                    showAddTaskFields = false
                }) {
                    Text("Submit Task")
                }
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(tasks) { (key, task) ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .background(
                            when (task.backgroundColor) {
                                "White" -> Color.White
                                "Peach" -> Color(0xFFFFE5B4)
                                "Black" -> Color.Black
                                "Blue" -> Color(0xFFD0E8F2)
                                else -> Color.Transparent
                            }
                        )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.completed, onCheckedChange = { checked ->
                            val updated = task.copy(completed = checked)
                            database.child(key).setValue(updated)
                        })
                        Column {
                            val displayColor = fontColorOptions[task.color] ?: Color.Gray
                            Text(
                                text = task.title,
                                fontSize = 18.sp,
                                fontWeight = if (task.bold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (task.italic) FontStyle.Italic else FontStyle.Normal,
                                color = displayColor
                            )
                            if (task.detail.isNotEmpty()) {
                                Text(text = task.detail, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = Color.Gray)
                            }
                            Text(text = if (task.completed) "✅ Completed" else "❌ Not yet", fontSize = 12.sp, color = if (task.completed) Color(0xFF10B981) else Color.Red)

                            if (task.subtasks.isNotEmpty()) {
                                Text("Subtasks:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.Gray)
                                task.subtasks.forEachIndexed { index, subtask ->
                                    val subColor = fontColorOptions[task.subtaskColors.getOrNull(index)] ?: Color.Gray
                                    Text("- $subtask", fontSize = 13.sp, color = subColor)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Button(onClick = { database.child(key).removeValue() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF87171))) {
                            Text("Delete", color = Color.White)
                        }
                        Button(onClick = {
                            val updated = task.copy(bold = !task.bold)
                            database.child(key).setValue(updated)
                        }) {
                            Text(if (task.bold) "Unbold" else "Bold")
                        }
                        Button(onClick = {
                            val updated = task.copy(italic = !task.italic)
                            database.child(key).setValue(updated)
                        }) {
                            Text(if (task.italic) "Unitalic" else "Italic")
                        }
                        Button(onClick = {
                            val colors = fontColorOptions.keys.toList()
                            val nextColor = colors[(colors.indexOf(task.color).let { if (it >= 0) it else 0 } + 1) % colors.size]
                            val updated = task.copy(color = nextColor)
                            database.child(key).setValue(updated)
                        }) {
                            Text("Color")
                        }
                    }

                    Button(onClick = {
                        taskTitle = task.title
                        taskDetail = task.detail
                        subtasks = task.subtasks.toMutableList()
                        subtaskColors = task.subtaskColors.toMutableList()
                        bold = task.bold
                        italic = task.italic
                        color = task.color
                        subtaskColor = "Gray"
                        taskBackground = task.backgroundColor
                        showAddTaskFields = true
                        editingKey = key
                    }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("Edit")
                    }
                }
                Divider(modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}

@Composable
fun DropdownMenuBox(options: List<String>, selectedOption: String, onOptionSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        Button(
            onClick = { expanded = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B4513)),
            shape = RoundedCornerShape(0.dp)
        ) {
            Text(selectedOption, color = Color.White)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
